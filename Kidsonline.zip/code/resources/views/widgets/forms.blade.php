<div class="row">
  <div class="col-sm-4">
    <form>
      <div class="form-group">
        <label for="exampleInputEmail1">Name</label>
        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter name">
      </div>
      <div class="checkbox">
        <label>
          <input type="checkbox"> Check me out
        </label>
      </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form>
  </div>
<div class="col-sm-3"></div>
  <div class="col-sm-5">

    <div class="onoffswitch">
      <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="myonoffswitch" checked>
      <label class="onoffswitch-label" for="myonoffswitch">
        <span class="onoffswitch-inner"></span>
        <span class="onoffswitch-switch"></span>
      </label>
    </div>
<div class="onoffswitch2">
    <input type="checkbox" name="onoffswitch2" class="onoffswitch-checkbox2" id="myonoffswitch2" checked>
    <label class="onoffswitch-label2" for="myonoffswitch2">
        <span class="onoffswitch-inner2"></span>
        <span class="onoffswitch-switch2"></span>
    </label>
</div>
  </div>
</div>
<div class="row">
  <div class="col-sm-8">
    <p>Add <code>.form-search</code> to the form and <code>.search-query</code> to the <code>input</code> for an extra-rounded text input.</p>
    <form class="form-search">
      <input type="text" class="border-radius-none input-medium search-query">
      <button type="submit" class="btn btn-primary">Search</button>
    </form>
  </div>
</div>