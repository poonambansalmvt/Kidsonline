<div class="container" align="center">
	<small>&copy; Laravel </small>
</div> 

