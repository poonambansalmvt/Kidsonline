<?php $__env->startSection('page_heading','Settings'); ?>

<?php $__env->startSection('section'); ?>
<div class="col-sm-6">
<div class="row">


     <!-- <div class="col-lg-6"> -->
        
            <div class="form-group">
                
                <label>Contact-form Email</label>
                <input class="form-control" name="contactemail" value="<?php echo $data[0]->email; ?>" disabled="disabled">
                <!-- <p class="help-block">Example block-level help text here.</p> -->
            </div>
           
            
          
            <a class="btn btn-default" href="<?php echo e(url('/admin/setting-email')); ?>/<?php echo $data[0]->id; ?>">Edit</a>
            
        
   
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>