<?php $__env->startSection('content'); ?>



<div class="motopress-wrapper content-holder clearfix main-holder">
  <div class="container">
    <div class="row">
      <div class="flexslider">
        <ul class="slides">
          <li>
            <img src="http://kidsonline.devserver.co.in/assets/images/slides1.jpg" />
          </li>
          <li>
            <img src="http://kidsonline.devserver.co.in/assets/images/slides2.jpg" />
          </li>
          <li>
            <img src="http://kidsonline.devserver.co.in/assets/images/slides3.jpg" />
          </li>

        </ul>
      </div>
      

    </div>

    <div class="row text-left">

      <div class="col-md-4 hero-feature padding-leftright">
        <div class="thumbnail">
          <img src="http://kidsonline.devserver.co.in/assets/images/11.jpg" alt="">
          <div class="caption">
            <h3>LATEST EPISODES</h3>
            <p>Nulla pretium congue tellus non congue. Quisque
              sodales, ipsum non maximus imperdiet, risus
              sapien gravida massa,ui.</p>

            </div>
          </div>
          <div class="hero-featuresecond caption">
            <a href="" class="btn btn-primary" title="Latest episodes">See all</a>

          </div>
        </div>

        <div class="col-md-4 hero-feature padding-leftright">
          <div class="thumbnail">
            <img src="http://kidsonline.devserver.co.in/assets/images/12.jpg" alt="">
            <div class="captions">
              <h3>LAST ADDED SHOW</h3>
              <p>Nulla pretium congue tellus non congue. Quisque
                sodales, ipsum non maximus imperdiet, risus
                sapien gravida massa,ui.</p>

              </div>
            </div>
            <div class="hero-featuresecond caption">
              <a href="" class="btn btn-primary" title="Latest episodes">See all</a>

            </div>
          </div>

          <div class="col-md-4 hero-feature padding-leftright">
            <div class="thumbnail">
              <img src="http://kidsonline.devserver.co.in/assets/images/13.jpg" alt="">
              <div class="captionThree">
                <h3>FAVORITES</h3>
                <p>Nulla pretium congue tellus non congue. Quisque
                  sodales, ipsum non maximus imperdiet, risus
                  sapien gravida massa,ui.</p>

                </div>
              </div>
              <div class="hero-featuresecond caption">
                <a href="" class="btn btn-primary" title="Latest episodes">See all</a>

              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 padding-leftright">
              <div class="box">
                <h2>Most popular</h2>
                <ul class="posts-grid row-fluid unstyled popular">
                 <li class="span4 item_1">
                   <figure class="featured-thumbnail thumbnail"><a href="<?php echo e(url('/movies')); ?>" title="Kids Online"><img src="http://kidsonline.devserver.co.in/assets/images/1.jpg" alt="Kids Online"></a></figure>
                   <div class="clear"></div>
                   <div class="post_meta">
                    <span class="post_comment"><a href="" class="comments_link">8 Comments</a></span>
                  </div>
                  <p class="excerpt">
                    <a href="" title="Kids Online">Maecenas ut magna
                      ut nunc faucibus
                      luctus et eget ex. </a></p>
                    </li>
                    <li class="span4 item_2">
                      <figure class="featured-thumbnail thumbnail"><a href="" title="Kids Online"><img src="http://kidsonline.devserver.co.in/assets/images/2.jpg" alt="Kids Online"></a></figure>
                      <div class="clear"></div>
                      <div class="post_meta">
                        <span class="post_comment"><a href="" class="comments_link">8 Comments</a></span>
                      </div>
                      <p class="excerpt">
                        <a href="" title="Kids Online">Maecenas ut magna
                          ut nunc faucibus
                          luctus et eget ex. </a></p>
                        </li>
                        <li class="span4 item_3">
                          <figure class="featured-thumbnail thumbnail"><a href="" title="Kids Online"><img src="http://kidsonline.devserver.co.in/assets/images/3.jpg" alt="Kids Online"></a></figure>
                          <div class="clear"></div>
                          <div class="post_meta">
                            <span class="post_comment"><a href="" class="comments_link">8 Comments</a></span>
                          </div>
                          <p class="excerpt">
                            <a href="" title="Kids Online">Maecenas ut magna
                              ut nunc faucibus
                              luctus et eget ex. </a></p>
                            </li>      

                          </ul>

                        </div>
                        <div class="hero-featuresecond caption">
                          <a href="" class="btn btn-primary" title="Latest episodes">See all</a>
                        </div>

                      </div>
                      <div class="col-md-4 padding-leftright">
                       <div class="box">
                         <h2>WHAT’S NEW?</h2>
                         <ul class="posts-grid row-fluid unstyled popular">
                           <li class="span4 item_1">
                             <figure class="featured-thumbnail thumbnail"><a href="" title="Kids Online"><img src="http://kidsonline.devserver.co.in/assets/images/4.jpg" alt="Kids Online"></a></figure>
                             <div class="clear"></div>
                             <div class="post_meta">
                               <span class="post_comment"><a href="" class="comments_link">0 Comments</a></span>
                             </div>
                             <p class="excerpt">
                              <a href="" title="Kids Online">Maecenas ut magna
                                ut nunc faucibus
                                luctus et eget ex. </a></p>
                              </li>
                              <li class="span4 item_2">
                                <figure class="featured-thumbnail thumbnail"><a href="" title="Kids Online"><img src="http://kidsonline.devserver.co.in/assets/images/5.jpg" alt="Kids Online"></a></figure>
                                <div class="clear"></div>
                                <div class="post_meta">
                                 <span class="post_comment"><a href="" class="comments_link">0 Comments</a></span>
                               </div>
                               <p class="excerpt">
                                <a href="" title="Kids Online">Maecenas ut magna
                                  ut nunc faucibus
                                  luctus et eget ex. </a></p>
                                </li>
                                <li class="span4 item_3">
                                  <figure class="featured-thumbnail thumbnail"><a href="" title="Kids Online"><img src="http://kidsonline.devserver.co.in/assets/images/6.jpg" alt="Kids Online"></a></figure>
                                  <div class="clear"></div>
                                  <div class="post_meta">
                                   <span class="post_comment"><a href="" class="comments_link">0 Comments</a></span>
                                 </div>
                                 <p class="excerpt">
                                  <a href="" title="Kids Online">Maecenas ut magna
                                    ut nunc faucibus
                                    luctus et eget ex. </a></p>
                                  </li>      

                                </ul>

                              </div>
                              <div class="hero-featuresecond caption">
                               <a href="" class="btn btn-primary" title="Latest episodes">See all</a>
                             </div>

                           </div>
                           <div class="col-md-4 padding-leftright">
                             <div class="box_1">
                               <h2>REVIEWS</h2>
                               <div class="accordion" id="accordion">
                                <div class="accordion-group">
                                  <div class="accordion-heading">
                                    <a class="accordion-toggle active" data-toggle="collapse" data-parent="#accordion" href="#panel1">Lorem ipsum dolor sit amet cons</a>
                                  </div>
                                  <div id="panel1" class="accordion-body in collapse">
                                    <div class="accordion-inner">
                                      Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et</div>
                                    </div>
                                  </div>
                                  <div class="accordion-group">
                                    <div class="accordion-heading">

                                      <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#panel2">Ipsum dolor sit amet cons</a>


                                    </div>
                                    <div id="panel2" class="accordion-body  collapse">
                                      <div class="accordion-inner">Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et</div>
                                    </div>
                                  </div>
                                  <div class="accordion-group">
                                    <div class="accordion-heading">

                                      <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#panel3">Ipsum dolor sit amet cons</a>


                                    </div>
                                    <div id="panel3" class="accordion-body  collapse">
                                      <div class="accordion-inner">Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et</div>
                                    </div>
                                  </div>
                                  <div class="accordion-group">
                                    <div class="accordion-heading">

                                      <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#panel4">Ipsum dolor sit amet cons</a>


                                    </div>
                                    <div id="panel4" class="accordion-body  collapse">
                                      <div class="accordion-inner">Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et</div>
                                    </div>
                                  </div>
                                  <div class="accordion-group">
                                    <div class="accordion-heading">

                                      <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#panel5">Ipsum dolor sit amet cons</a>


                                    </div>
                                    <div id="panel5" class="accordion-body  collapse">
                                      <div class="accordion-inner">Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et</div>
                                    </div>
                                  </div>
                                </div>
                              </div>

                            </div>


                          </div>

                        </div>
                      </div>

                    </div>


                  </div>
                  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>