
<?php $__env->startSection('page_heading','Update-Email'); ?>

<?php $__env->startSection('section'); ?>

<div class="col-sm-6">
<div class="row">


     
        <form role="form" action="<?php echo e(action('HomeController@updatesettings')); ?>" method="post">
            <div class="form-group">
                <input type="hidden" value="<?php echo $data[0]->id; ?>" name="id">
                <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                <label>Contact-form Email</label>
                <input class="form-control" name="email" value="<?php echo $data[0]->email;?>">
                
            </div>
            
           
            
            <button type="submit" class="btn btn-default">Update</button>
            
        </form>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>