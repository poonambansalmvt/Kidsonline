
<?php $__env->startSection('page_heading','Slider-Images'); ?>

<?php $__env->startSection('section'); ?>

<div class="col-sm-12">
<div class="row">
<table class="table table-hover">
    <thead>
      <tr>
        <th>Serial No</th>
        <th>Image Nmae</th>
        <th>Image</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php $i = 1 ; foreach ($data as $key => $value) { ?>
      <tr>
        <td><?php echo $i ; ?></td>
        <td><?php echo $value->imgname;?></td>
        <td><img style = "width:150px;" src="<?php echo $value->imgpath; ?>"/></td>
        <td><a href="<?php echo e(url('/admin/editSliderimg')); ?>/<?php echo $value->id; ?>">Edit</a>/<a href="<?php echo e(url('/admin/sliderimgList')); ?>/<?php echo $value->id; ?>">Delete</a></td>
      </tr>
      <?php $i++;} ?>
    </tbody>
  </table>
  
	
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>