<?php $__env->startSection('content'); ?>
<div class="motopress-wrapper content-holder clearfix about main-holder">
	<div class="container">
		<div class="row">
			<div class="col-md-12 padding_nill">
				<section class="title-section">
					<h1 class="title-header">Terms & Conditions </h1>
					<ul class="breadcrumb breadcrumb__t">
						<li><a href="<?php echo e(url('/')); ?>">Home</a>
						</li>
						<!-- <li class="divider">
						</li><li>
						<a href="" title="View all">Uncategorized</a>
					</li> -->
					<li class="divider"></li>
					<li class="active">Terms & Conditions</li></ul>  
				</section>
			</div>
			<div class="col-md-12 padding_nill">
				<article class="post__holder post">
					<h3>Terms & Conditions </h3>
					<div class="post_content">
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed blandit massa vel mauris sollicitudin dignissim. Phasellus ultrices tellus eget ipsum ornare molestie scelerisque eros dignissim. Phasellus fringilla hendrerit lectus nec vehicula. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. </p>

						<div class="clear"></div>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed blandit massa vel mauris sollicitudin dignissim. Phasellus ultrices tellus eget ipsum ornare molestie scelerisque eros dignissim. Phasellus fringilla hendrerit lectus nec vehicula. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. </p>
					</div>

				</article>	
			</div>
		</div>
	</div>
</div>					

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>