<?php $__env->startSection('page_heading','Series-list'); ?>
<?php $__env->startSection('section'); ?>
<div class="col-sm-12">
	<div class="row">
		<table class="table table-hover">
	    <thead>
	      <tr>
	        <th>Id</th>
	        <th>Title</th>
	        <th>Image</th>
	        <th>Imdb-rating</th>
	        <th style="width: 14%;">Tomato-user-rating</th>
	        <th>Desciption</th>
	        <th>Duration</th>
	        <th>Action</th>
	      </tr>
	    </thead>
	    <tbody>
	    <?php $i = 1 ; foreach ($data as $key => $value) { ?>
	      <tr>
	        <td><?php echo $i ; ?></td>
	        <td><?php echo $value->title;?></td>
	        <td><img style = "height:60px;width:60px;" src="<?php if($value->poster != 'N/A'){echo $value->poster;}else{ echo "http://kidsonline.devserver.co.in/assets/images/default-slide-img.jpg";	}?>"/></td>
	        <td><?php echo $value->imdb_rating;?></td>
	        <td><?php echo $value->tomato_user_rating;?></td>
	        <td><?php echo $value->plot;?></td>
	        <td><?php echo $value->runtime;?></td>
	        <td><a href="<?php echo e(url('/admin/editSeries')); ?>/<?php echo $value->omdb_id; ?>">Edit</a>/Delete</td>
	      </tr>
	      <?php $i++;} ?>
	    </tbody>
	  </table>
	  <div class="pagination" style="float:right;"><?php echo e($data->links()); ?></div>
		<!-- <div class="col-sm-6">
			<?php $__env->startSection('cchart1_panel_title','Line Chart'); ?>
			<?php $__env->startSection('cchart1_panel_body'); ?>
			<?php echo $__env->make('widgets.charts.clinechart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php $__env->stopSection(); ?>
			<?php echo $__env->make('widgets.panel', array('header'=>true, 'as'=>'cchart1'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<?php $__env->startSection('cchart3_panel_title','Donut Chart'); ?>
			<?php $__env->startSection('cchart3_panel_body'); ?>
				<div style="max-width:400px; margin:0 auto;"><?php echo $__env->make('widgets.charts.cdonutchart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
			<?php $__env->stopSection(); ?>
			<?php echo $__env->make('widgets.panel', array('header'=>true, 'as'=>'cchart3'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
		<div class="col-sm-6">
			
			<?php $__env->startSection('cchart2_panel_title','Pie Chart'); ?>
			<?php $__env->startSection('cchart2_panel_body'); ?>
				<div style="max-width:400px; margin:0 auto;"><?php echo $__env->make('widgets.charts.cpiechart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
			<?php $__env->stopSection(); ?>
			<?php echo $__env->make('widgets.panel', array('header'=>true, 'as'=>'cchart2'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<?php $__env->startSection('cchart4_panel_title','Bar Chart'); ?>
			<?php $__env->startSection('cchart4_panel_body'); ?>
			<?php echo $__env->make('widgets.charts.cbarchart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php $__env->stopSection(); ?>
			<?php echo $__env->make('widgets.panel', array('header'=>true, 'as'=>'cchart4'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div> --> 
	</div>
	
	
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>